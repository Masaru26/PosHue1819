﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YUSUPOV_5EHIF_KomplexZahlen
{
    class ComplexNumber
    {
        Cartesian cartesian;
        Polar polar;

        public ComplexNumber(Cartesian cartesian)
        {
            this.cartesian = cartesian;
            this.polar = this.cartesian.toPolar();
        }

        public ComplexNumber(Polar polar)
        {
            this.polar = polar;
            this.cartesian = polar.toCartesian();
        }

        public ComplexNumber Add(ComplexNumber b)
        {
            double rImaginary = cartesian.imaginary + b.cartesian.imaginary;
            double rReal = cartesian.real + b.cartesian.real;

            return new ComplexNumber(new Cartesian(rReal, rImaginary));
        }

        public ComplexNumber Substract(ComplexNumber b)
        {
            double rImaginary = cartesian.imaginary - b.cartesian.imaginary;
            double rReal = cartesian.real - b.cartesian.real;

            return new ComplexNumber(new Cartesian(rReal, rImaginary));
        }

        public double getImaginary()
        {
            return cartesian.imaginary;
        }

        public double getReal()
        {
            return cartesian.real;
        }

        public double getLength()
        {
            return polar.length;
        }

        public double getDegree()
        {
            return polar.degree;
        }
    }

    public class Polar
    {
        public double length;
        public double degree;

        public Polar(double length, double degree)
        {
            this.length = length;
            this.degree = degree;
        }

        public Cartesian toCartesian()
        {
            double real = Math.Cos(degree) * length;
            double imaginary = Math.Sin(degree) * length;

            return new Cartesian(real, imaginary);
        }
    }

    public class Cartesian
    {
        public double real;
        public double imaginary;

        public Cartesian(double real, double imaginary)
        {
            this.real = real;
            this.imaginary = imaginary;
        }
        public Polar toPolar()
        {
            double length = Math.Sqrt(imaginary * imaginary + real * real);
            double radians = Math.Atan(imaginary / real);
            double degree = (180 / Math.PI) * radians;

            return new Polar(length, degree);
        }
    }
}
