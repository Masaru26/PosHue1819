﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YUSUPOV_5EHIF_KomplexZahlen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            double aReal = 0;
            double aImaginary = 0;
            double bReal = 0;
            double bImaginary = 0;

            Double.TryParse(aRealPart.Text, out aReal);
            Double.TryParse(aImaginaryPart.Text, out aImaginary);
            Double.TryParse(bRealPart.Text, out bReal);
            Double.TryParse(bImaginaryPart.Text, out bImaginary);

            if(opPlus.Checked || opMinus.Checked)
            {
                if(radioCartesian.Checked)
                {
                    if(opPlus.Checked)
                    {
                        ComplexNumber cA = new ComplexNumber(new Cartesian(aReal, aImaginary));
                        ComplexNumber cB = new ComplexNumber(new Cartesian(bReal, bImaginary));

                        ComplexNumber result = cA.Add(cB);

                        resultImaginary.Text = result.getImaginary().ToString();
                        resultReal.Text = result.getReal().ToString();
                    }else
                    {
                        ComplexNumber cA = new ComplexNumber(new Cartesian(aReal, aImaginary));
                        ComplexNumber cB = new ComplexNumber(new Cartesian(bReal, bImaginary));

                        ComplexNumber result = cA.Substract(cB);

                        resultImaginary.Text = result.getImaginary().ToString();
                        resultReal.Text = result.getReal().ToString();
                    }
                    
                }else if(radioPolar.Checked)
                {
                    ComplexNumber cA = new ComplexNumber(new Cartesian(aReal, aImaginary));
                    ComplexNumber cB = new ComplexNumber(new Cartesian(bReal, bImaginary));

                    ComplexNumber result = cA.Add(cB);

                    resultImaginary.Text = result.getDegree().ToString();
                    resultReal.Text = result.getLength().ToString();
                }
                else
                {
                    MessageBox.Show("Kein Ergebnisformat ausgewählt");
                }
                
            }
            else if(opMult.Checked || opDiv.Checked)
            {

            }else
            {
                MessageBox.Show("No Operation selected");
            }
        }
    }
}
