﻿namespace YUSUPOV_5EHIF_KomplexZahlen
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.cartesianTabStop = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.resultImaginary = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.resultReal = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.bImaginaryPart = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.bRealPart = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.opDiv = new System.Windows.Forms.RadioButton();
            this.opMult = new System.Windows.Forms.RadioButton();
            this.opMinus = new System.Windows.Forms.RadioButton();
            this.opPlus = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.aImaginaryPart = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.aRealPart = new System.Windows.Forms.TextBox();
            this.polarTabStop = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.radioPolar = new System.Windows.Forms.RadioButton();
            this.radioCartesian = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.cartesianTabStop.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.polarTabStop.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.cartesianTabStop);
            this.tabControl1.Controls.Add(this.polarTabStop);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.HotTrack = true;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 295);
            this.tabControl1.TabIndex = 0;
            // 
            // cartesianTabStop
            // 
            this.cartesianTabStop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.cartesianTabStop.Controls.Add(this.label7);
            this.cartesianTabStop.Controls.Add(this.groupBox4);
            this.cartesianTabStop.Controls.Add(this.groupBox3);
            this.cartesianTabStop.Controls.Add(this.groupBox2);
            this.cartesianTabStop.Controls.Add(this.groupBox1);
            this.cartesianTabStop.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.cartesianTabStop.Location = new System.Drawing.Point(4, 22);
            this.cartesianTabStop.Name = "cartesianTabStop";
            this.cartesianTabStop.Padding = new System.Windows.Forms.Padding(3);
            this.cartesianTabStop.Size = new System.Drawing.Size(792, 269);
            this.cartesianTabStop.TabIndex = 0;
            this.cartesianTabStop.Text = "Cartesian Coordinates";
            this.cartesianTabStop.UseVisualStyleBackColor = true;
            this.cartesianTabStop.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(549, 107);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 42);
            this.label7.TabIndex = 6;
            this.label7.Text = "=";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox9);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.resultImaginary);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.resultReal);
            this.groupBox4.Location = new System.Drawing.Point(606, 25);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(154, 220);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Result";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Output B";
            // 
            // resultImaginary
            // 
            this.resultImaginary.Location = new System.Drawing.Point(27, 99);
            this.resultImaginary.Name = "resultImaginary";
            this.resultImaginary.Size = new System.Drawing.Size(100, 20);
            this.resultImaginary.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 33);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Output A";
            // 
            // resultReal
            // 
            this.resultReal.Location = new System.Drawing.Point(27, 49);
            this.resultReal.Name = "resultReal";
            this.resultReal.Size = new System.Drawing.Size(100, 20);
            this.resultReal.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.bImaginaryPart);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.bRealPart);
            this.groupBox3.Location = new System.Drawing.Point(375, 25);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(154, 220);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Operand B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Imaginary";
            // 
            // bImaginaryPart
            // 
            this.bImaginaryPart.Location = new System.Drawing.Point(24, 154);
            this.bImaginaryPart.Name = "bImaginaryPart";
            this.bImaginaryPart.Size = new System.Drawing.Size(100, 20);
            this.bImaginaryPart.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Real Part";
            // 
            // bRealPart
            // 
            this.bRealPart.Location = new System.Drawing.Point(24, 77);
            this.bRealPart.Name = "bRealPart";
            this.bRealPart.Size = new System.Drawing.Size(100, 20);
            this.bRealPart.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.opDiv);
            this.groupBox2.Controls.Add(this.opMult);
            this.groupBox2.Controls.Add(this.opMinus);
            this.groupBox2.Controls.Add(this.opPlus);
            this.groupBox2.Location = new System.Drawing.Point(193, 53);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(154, 171);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Operator";
            // 
            // opDiv
            // 
            this.opDiv.AutoSize = true;
            this.opDiv.Location = new System.Drawing.Point(25, 125);
            this.opDiv.Name = "opDiv";
            this.opDiv.Size = new System.Drawing.Size(30, 17);
            this.opDiv.TabIndex = 3;
            this.opDiv.TabStop = true;
            this.opDiv.Text = "/";
            this.opDiv.UseVisualStyleBackColor = true;
            // 
            // opMult
            // 
            this.opMult.AutoSize = true;
            this.opMult.Location = new System.Drawing.Point(25, 102);
            this.opMult.Name = "opMult";
            this.opMult.Size = new System.Drawing.Size(29, 17);
            this.opMult.TabIndex = 2;
            this.opMult.TabStop = true;
            this.opMult.Text = "*";
            this.opMult.UseVisualStyleBackColor = true;
            // 
            // opMinus
            // 
            this.opMinus.AutoSize = true;
            this.opMinus.Location = new System.Drawing.Point(25, 77);
            this.opMinus.Name = "opMinus";
            this.opMinus.Size = new System.Drawing.Size(28, 17);
            this.opMinus.TabIndex = 1;
            this.opMinus.TabStop = true;
            this.opMinus.Text = "-";
            this.opMinus.UseVisualStyleBackColor = true;
            // 
            // opPlus
            // 
            this.opPlus.AutoSize = true;
            this.opPlus.Location = new System.Drawing.Point(25, 54);
            this.opPlus.Name = "opPlus";
            this.opPlus.Size = new System.Drawing.Size(31, 17);
            this.opPlus.TabIndex = 0;
            this.opPlus.TabStop = true;
            this.opPlus.Text = "+";
            this.opPlus.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.aImaginaryPart);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.aRealPart);
            this.groupBox1.Location = new System.Drawing.Point(15, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(154, 220);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Operand A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Imaginary";
            // 
            // aImaginaryPart
            // 
            this.aImaginaryPart.Location = new System.Drawing.Point(24, 154);
            this.aImaginaryPart.Name = "aImaginaryPart";
            this.aImaginaryPart.Size = new System.Drawing.Size(100, 20);
            this.aImaginaryPart.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Real Part";
            // 
            // aRealPart
            // 
            this.aRealPart.Location = new System.Drawing.Point(24, 77);
            this.aRealPart.Name = "aRealPart";
            this.aRealPart.Size = new System.Drawing.Size(100, 20);
            this.aRealPart.TabIndex = 0;
            // 
            // polarTabStop
            // 
            this.polarTabStop.Controls.Add(this.groupBox5);
            this.polarTabStop.Controls.Add(this.label8);
            this.polarTabStop.Controls.Add(this.groupBox6);
            this.polarTabStop.Controls.Add(this.groupBox7);
            this.polarTabStop.Controls.Add(this.groupBox8);
            this.polarTabStop.Location = new System.Drawing.Point(4, 22);
            this.polarTabStop.Name = "polarTabStop";
            this.polarTabStop.Padding = new System.Windows.Forms.Padding(3);
            this.polarTabStop.Size = new System.Drawing.Size(792, 269);
            this.polarTabStop.TabIndex = 1;
            this.polarTabStop.Text = "Polar Coordinates";
            this.polarTabStop.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(558, 106);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 42);
            this.label8.TabIndex = 11;
            this.label8.Text = "=";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.textBox3);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.textBox4);
            this.groupBox6.Location = new System.Drawing.Point(384, 24);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(154, 220);
            this.groupBox6.TabIndex = 8;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Operand B";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 128);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "Imaginary";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(24, 154);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(21, 51);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 13);
            this.label12.TabIndex = 1;
            this.label12.Text = "Real Part";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(24, 77);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radioButton1);
            this.groupBox7.Controls.Add(this.radioButton2);
            this.groupBox7.Controls.Add(this.radioButton3);
            this.groupBox7.Controls.Add(this.radioButton4);
            this.groupBox7.Location = new System.Drawing.Point(204, 51);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(154, 171);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Operator";
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(25, 125);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(30, 17);
            this.radioButton1.TabIndex = 3;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "/";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(25, 102);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(29, 17);
            this.radioButton2.TabIndex = 2;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "*";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(25, 77);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(28, 17);
            this.radioButton3.TabIndex = 1;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "-";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(25, 54);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(31, 17);
            this.radioButton4.TabIndex = 0;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "+";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.textBox5);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Controls.Add(this.textBox6);
            this.groupBox8.Location = new System.Drawing.Point(24, 24);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(154, 220);
            this.groupBox8.TabIndex = 7;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Operand A";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(21, 128);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 3;
            this.label13.Text = "Winkel";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(24, 154);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(21, 51);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 13);
            this.label14.TabIndex = 1;
            this.label14.Text = "Länge";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(24, 77);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 0;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.radioCartesian);
            this.groupBox9.Controls.Add(this.radioPolar);
            this.groupBox9.Location = new System.Drawing.Point(6, 154);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(142, 60);
            this.groupBox9.TabIndex = 4;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Anzeige";
            // 
            // radioPolar
            // 
            this.radioPolar.AutoSize = true;
            this.radioPolar.Location = new System.Drawing.Point(6, 14);
            this.radioPolar.Name = "radioPolar";
            this.radioPolar.Size = new System.Drawing.Size(49, 17);
            this.radioPolar.TabIndex = 7;
            this.radioPolar.TabStop = true;
            this.radioPolar.Text = "Polar";
            this.radioPolar.UseVisualStyleBackColor = true;
            // 
            // radioCartesian
            // 
            this.radioCartesian.AutoSize = true;
            this.radioCartesian.Location = new System.Drawing.Point(6, 37);
            this.radioCartesian.Name = "radioCartesian";
            this.radioCartesian.Size = new System.Drawing.Size(69, 17);
            this.radioCartesian.TabIndex = 8;
            this.radioCartesian.TabStop = true;
            this.radioCartesian.Text = "Cartesian";
            this.radioCartesian.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.groupBox10);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.textBox2);
            this.groupBox5.Location = new System.Drawing.Point(604, 24);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(154, 220);
            this.groupBox5.TabIndex = 12;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Result";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.radioButton7);
            this.groupBox10.Controls.Add(this.radioButton8);
            this.groupBox10.Location = new System.Drawing.Point(6, 154);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(142, 60);
            this.groupBox10.TabIndex = 4;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Anzeige";
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(6, 37);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(69, 17);
            this.radioButton7.TabIndex = 8;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Cartesian";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(6, 14);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(49, 17);
            this.radioButton8.TabIndex = 7;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "Polar";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(52, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Imaginary";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(27, 99);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 13);
            this.label10.TabIndex = 1;
            this.label10.Text = "Real Part";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(27, 49);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 295);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.cartesianTabStop.ResumeLayout(false);
            this.cartesianTabStop.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.polarTabStop.ResumeLayout(false);
            this.polarTabStop.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage cartesianTabStop;
        private System.Windows.Forms.TabPage polarTabStop;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox resultImaginary;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox resultReal;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox bImaginaryPart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox bRealPart;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton opDiv;
        private System.Windows.Forms.RadioButton opMult;
        private System.Windows.Forms.RadioButton opMinus;
        private System.Windows.Forms.RadioButton opPlus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox aImaginaryPart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox aRealPart;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.RadioButton radioCartesian;
        private System.Windows.Forms.RadioButton radioPolar;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox2;
    }
}

